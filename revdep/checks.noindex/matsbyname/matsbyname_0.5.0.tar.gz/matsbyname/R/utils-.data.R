#' Data pronoun
#'
#' See [rlang::.data] for details.
#'
#' @name .data
#' @rdname data
#' @keywords internal
#' @export
#' @importFrom rlang .data
#' @usage .data
NULL
