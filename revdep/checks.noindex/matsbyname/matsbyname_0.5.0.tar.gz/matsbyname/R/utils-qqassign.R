#' Assignment
#'
#' See \code{rlang::\link[rlang]{:=}} for details.
#'
#' @name :=
#' @rdname quasi-quote-assign
#' @keywords internal
#' @export
#' @importFrom rlang :=
#' @usage x := y
NULL
