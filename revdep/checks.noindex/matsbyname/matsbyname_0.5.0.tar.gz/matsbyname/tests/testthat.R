library(testthat)

test_check("matsbyname")
